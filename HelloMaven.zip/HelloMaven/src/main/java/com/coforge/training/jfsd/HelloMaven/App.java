package com.coforge.training.jfsd.HelloMaven;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World! fom maven" );
        System.out.println();
   
    Student s1=new Student(101,"James Gosling","BTech",88);
    s1.display();
    
    
    
    }
}
